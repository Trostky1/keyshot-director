import {
  Aperture,
  ArrowUp,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Download,
  Film,
  Folder,
  Image,
  LampDesk,
  Layers3,
  Link,
  Maximize2,
  Menu,
  MessageSquare,
  Monitor,
  MoreHorizontal,
  MousePointer2,
  Paperclip,
  Play,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  Settings,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
  Square,
  Sun,
  Undo2,
  Upload,
  Video,
  WandSparkles,
  X,
  type LucideIcon,
} from "lucide-react"
import {
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react"

type Workspace = "studio" | "references" | "materials"

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  icon?: LucideIcon
  variant?: "primary" | "secondary" | "ghost" | "danger"
  compact?: boolean
}

function Button({
  icon: Icon,
  children,
  variant = "secondary",
  compact = false,
  className = "",
  ...props
}: ButtonProps) {
  return (
    <button
      className={`button button--${variant} ${
        compact ? "button--compact" : ""
      } ${className}`}
      {...props}
    >
      {Icon && <Icon aria-hidden="true" />}
      {children}
    </button>
  )
}

function IconButton({
  label,
  icon: Icon,
  active = false,
  onClick,
}: {
  label: string
  icon: LucideIcon
  active?: boolean
  onClick?: () => void
}) {
  return (
    <button
      aria-label={label}
      className={`icon-button ${active ? "is-active" : ""}`}
      onClick={onClick}
      title={label}
    >
      <Icon aria-hidden="true" />
    </button>
  )
}

function Toggle({
  checked,
  label,
  onChange,
}: {
  checked: boolean
  label: string
  onChange: () => void
}) {
  return (
    <button
      className="toggle-row"
      role="switch"
      aria-checked={checked}
      onClick={onChange}
    >
      <span>{label}</span>
      <span className={`toggle ${checked ? "is-on" : ""}`}>
        <span />
      </span>
    </button>
  )
}

function Segmented({
  options,
  value,
  onChange,
}: {
  options: string[]
  value: string
  onChange: (value: string) => void
}) {
  return (
    <div className="segmented">
      {options.map((option) => (
        <button
          className={value === option ? "is-active" : ""}
          key={option}
          onClick={() => onChange(option)}
        >
          {option}
        </button>
      ))}
    </div>
  )
}

function Disclosure({
  title,
  icon: Icon,
  children,
  defaultOpen = false,
  badge,
}: {
  title: string
  icon: LucideIcon
  children: ReactNode
  defaultOpen?: boolean
  badge?: string
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <section className={`disclosure ${open ? "is-open" : ""}`}>
      <button className="disclosure__trigger" onClick={() => setOpen(!open)}>
        <span className="disclosure__title">
          <Icon aria-hidden="true" />
          {title}
        </span>
        <span className="disclosure__meta">
          {badge && <span className="micro-badge">{badge}</span>}
          <ChevronDown aria-hidden="true" />
        </span>
      </button>
      {open && <div className="disclosure__content">{children}</div>}
    </section>
  )
}

function SceneCanvas() {
  const [playing, setPlaying] = useState(true)
  const [view, setView] = useState("Orbit")
  return (
    <section className="scene" aria-label="Live KeyShot scene preview">
      <div className="scene__ambient scene__ambient--one" />
      <div className="scene__ambient scene__ambient--two" />
      <div className="scene__topbar">
        <span className="scene__label">
          <span className={`status-dot ${playing ? "status-dot--live" : ""}`} />
          {playing ? "Live preview" : "Preview paused"}
        </span>
        <div className="toolbar">
          <IconButton
            label={playing ? "Pause preview" : "Play preview"}
            icon={playing ? Square : Play}
            onClick={() => setPlaying(!playing)}
          />
          <IconButton label="Refresh scene" icon={RefreshCw} />
          <IconButton label="Fit view" icon={Maximize2} />
          <IconButton label="More scene options" icon={MoreHorizontal} />
        </div>
      </div>

      <div
        className="product-render"
        aria-label="Illustrative live scene preview"
      >
        <div className="product-render__shadow" />
        <div className="product-render__body">
          <div className="product-render__edge" />
          <div className="product-render__screen">
            <div className="screen-glow" />
            <span>KS</span>
          </div>
          <div className="product-render__deck">
            <i />
            <i />
            <i />
            <i />
          </div>
        </div>
      </div>

      <div className="scene__views">
        {["Orbit", "Front", "Top"].map((item) => (
          <button
            className={view === item ? "is-active" : ""}
            key={item}
            onClick={() => setView(item)}
          >
            {item}
          </button>
        ))}
      </div>
      <div className="scene__hint">
        <MousePointer2 aria-hidden="true" />
        Drag to orbit
        <span />
        Right-drag to pan
        <span />
        Scroll to zoom
      </div>
      <span className="scene__preview-note">
        Illustrative preview · KeyShot remains the visual source of truth
      </span>
    </section>
  )
}

function DirectorChat() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<string[]>([])
  const send = () => {
    if (!message.trim()) return
    setMessages((current) => [...current, message.trim()])
    setMessage("")
  }
  return (
    <section className="director">
      <div className="section-heading">
        <div>
          <span className="eyebrow">
            <Sparkles /> Creative assistant
          </span>
          <h2>Ask Director</h2>
          <p>Lighting, framing, scene layout, and motion.</p>
        </div>
        {messages.length > 0 && (
          <Button
            icon={Plus}
            variant="ghost"
            compact
            onClick={() => setMessages([])}
          >
            New chat
          </Button>
        )}
      </div>
      <div className="conversation" aria-live="polite">
        {messages.length === 0 ? (
          <div className="conversation__empty">
            <span className="empty-icon">
              <MessageSquare />
            </span>
            <div>
              <strong>What would you like to shape?</strong>
              <p>Try a lighting direction, camera move, or scene adjustment.</p>
            </div>
          </div>
        ) : (
          messages.map((item, index) => (
            <div className="message" key={`${item}-${index}`}>
              {item}
            </div>
          ))
        )}
      </div>
      <div className="suggestions">
        {[
          "Add a soft rim light",
          "Frame a detail close-up",
          "Create a slow turntable",
        ].map((item) => (
          <button key={item} onClick={() => setMessage(item)}>
            {item}
          </button>
        ))}
      </div>
      <div className="composer">
        <textarea
          aria-label="Ask Director"
          placeholder="Describe a look, ask for a close-up, or arrange your product…"
          rows={2}
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault()
              send()
            }
          }}
        />
        <div className="composer__actions">
          <div>
            <IconButton label="Attach images" icon={Paperclip} />
            <span className="key-hint">↵ to send</span>
          </div>
          <div>
            <Button icon={Square} variant="ghost" compact disabled>
              Stop
            </Button>
            <Button
              icon={ArrowUp}
              variant="primary"
              compact
              onClick={send}
              disabled={!message.trim()}
            >
              Send
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

function MatchLook() {
  const fileRef = useRef<HTMLInputElement>(null)
  const [fileName, setFileName] = useState("")
  const [brief, setBrief] = useState("")
  const [framing, setFraming] = useState(false)
  const [matching, setMatching] = useState(false)
  const [matched, setMatched] = useState(false)

  const match = () => {
    setMatching(true)
    window.setTimeout(() => {
      setMatching(false)
      setMatched(true)
    }, 900)
  }

  return (
    <section className="inspector-section match-look">
      <div className="section-heading section-heading--compact">
        <div>
          <span className="eyebrow">
            <WandSparkles /> Guided workflow
          </span>
          <h2>Match a look</h2>
          <p>Bring the lighting and mood of a photo to your product.</p>
        </div>
        <span
          className={`state-badge ${matched ? "state-badge--success" : ""}`}
        >
          {matched ? (
            <Check />
          ) : (
            <span className="status-dot status-dot--live" />
          )}
          {matched ? "Matched" : "Ready"}
        </span>
      </div>

      <input
        className="visually-hidden"
        ref={fileRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        onChange={(event) => setFileName(event.target.files?.[0]?.name ?? "")}
      />
      <button
        className={`drop-zone ${fileName ? "has-file" : ""}`}
        onClick={() => fileRef.current?.click()}
      >
        <span className="drop-zone__icon">
          {fileName ? <Image /> : <Upload />}
        </span>
        <span>
          <strong>{fileName || "Add a reference photo"}</strong>
          <small>
            {fileName ? "Click to replace" : "Choose or drop · PNG, JPG, WebP"}
          </small>
        </span>
        {fileName && <Check className="check" />}
      </button>

      <label className="field">
        <span>What should we borrow?</span>
        <textarea
          rows={3}
          value={brief}
          onChange={(event) => setBrief(event.target.value)}
          placeholder="Soft side light, crisp edge reflections, a warm background…"
        />
      </label>
      <Toggle
        checked={framing}
        onChange={() => setFraming(!framing)}
        label="Match framing too"
      />
      <label className="select-field">
        <span>Refinement</span>
        <select defaultValue="Visual refinement">
          <option>Visual refinement</option>
          <option>Fast exploration</option>
          <option>Careful refinement</option>
        </select>
      </label>
      <Button
        className="full-width"
        icon={matching ? RefreshCw : WandSparkles}
        variant="primary"
        onClick={match}
        disabled={!fileName || matching}
      >
        {matching
          ? "Analyzing reference…"
          : matched
            ? "Match again"
            : "Match this look"}
      </Button>
      <div className="split-actions">
        <Button
          icon={RotateCcw}
          compact
          disabled={!matching && !matched}
          onClick={() => {
            setMatching(false)
            setMatched(false)
          }}
        >
          Stop & restore
        </Button>
        <Button
          icon={Undo2}
          compact
          disabled={!matched}
          onClick={() => setMatched(false)}
        >
          Undo look
        </Button>
      </div>
      <p className="privacy-note">
        Reference and preview images are shared with your selected AI provider
        and saved locally. Your materials stay untouched.
      </p>
    </section>
  )
}

function FrameControls() {
  const [frame, setFrame] = useState("Full product")
  const [groundShadow, setGroundShadow] = useState(true)
  const [reflections, setReflections] = useState(false)
  return (
    <div className="control-stack">
      <span className="field-label">Composition</span>
      <Segmented
        options={["Full product", "Detail", "Upper detail"]}
        value={frame}
        onChange={setFrame}
      />
      <label className="select-field">
        <span>Output</span>
        <select defaultValue="Landscape · 16:9">
          <option>Landscape · 16:9</option>
          <option>Square · 1:1</option>
          <option>Portrait · 4:5</option>
        </select>
      </label>
      <label className="field">
        <span>Backdrop</span>
        <input defaultValue="Warm gray sweep" />
      </label>
      <Toggle
        checked={groundShadow}
        onChange={() => setGroundShadow(!groundShadow)}
        label="Ground shadows"
      />
      <Toggle
        checked={reflections}
        onChange={() => setReflections(!reflections)}
        label="Ground reflections"
      />
    </div>
  )
}

function LightingControls() {
  const [rig, setRig] = useState("Hero soft")
  const [mirror, setMirror] = useState(false)
  return (
    <div className="control-stack">
      <Segmented
        options={["Hero soft", "Dark & moody", "Warm luxe"]}
        value={rig}
        onChange={setRig}
      />
      <label className="range-field">
        <span>
          <span>Exposure</span>
          <output>+0.4</output>
        </span>
        <input type="range" min="-2" max="2" step=".1" defaultValue=".4" />
      </label>
      <Toggle
        checked={mirror}
        onChange={() => setMirror(!mirror)}
        label="Mirror stage controls"
      />
      <div className="light-stage">
        <span className="stage-ring stage-ring--outer" />
        <span className="stage-ring stage-ring--inner" />
        <span className="stage-product">
          <Box />
        </span>
        <button
          className="light-node light-node--key"
          aria-label="Move key light"
        />
        <button
          className="light-node light-node--fill"
          aria-label="Move fill light"
        />
      </div>
      {[
        ["Key light", "72%"],
        ["Overhead", "48%"],
        ["Fill", "31%"],
      ].map(([name, value]) => (
        <div className="light-row" key={name}>
          <span>
            <Sun /> {name}
          </span>
          <small>{value}</small>
          <IconButton label={`Edit ${name}`} icon={SlidersHorizontal} />
          <IconButton label={`Remove ${name}`} icon={X} />
        </div>
      ))}
      <div className="split-actions">
        <Button icon={Plus} compact>
          Add light
        </Button>
        <Button icon={Square} variant="danger" compact>
          Studio off
        </Button>
      </div>
    </div>
  )
}

function StudioInspector() {
  return (
    <aside className="inspector">
      <MatchLook />
      <div className="disclosure-list">
        <Disclosure title="Frame & background" icon={Aperture} defaultOpen>
          <FrameControls />
        </Disclosure>
        <Disclosure title="Connect KeyShot" icon={Link} badge="Connected">
          <div className="connection-panel">
            <span className="state-badge state-badge--success">
              <Check /> KeyShot connected
            </span>
            <p>
              Director is receiving the active scene preview. Keep the KeyShot
              plugin open while you work.
            </p>
            <Button compact>Connection instructions</Button>
          </div>
        </Disclosure>
        <Disclosure title="Reference video & animation" icon={Video}>
          <div className="empty-inline">
            <Film />
            <div>
              <strong>No reference video</strong>
              <p>Add a motion reference or create a camera move.</p>
            </div>
            <Button icon={Upload} compact>
              Add video
            </Button>
          </div>
        </Disclosure>
        <Disclosure title="Studio lighting" icon={LampDesk}>
          <LightingControls />
        </Disclosure>
        <Disclosure title="Styles" icon={Layers3} badge="17">
          <div className="folder-list">
            <button>
              <Folder />
              <span>
                <strong>Commerce</strong>
                <small>17 images</small>
              </span>
              <ChevronDown />
            </button>
            <button>
              <Folder />
              <span>
                <strong>Closeups</strong>
                <small>0 images</small>
              </span>
              <ChevronDown />
            </button>
          </div>
        </Disclosure>
        <Disclosure title="Camera motion" icon={Film}>
          <p className="body-copy">
            Create turntables and camera paths from natural-language direction
            in Ask Director.
          </p>
        </Disclosure>
        <Disclosure title="Open on phone" icon={Smartphone}>
          <p className="body-copy">
            Continue this scene from a mobile browser on the same network.
          </p>
        </Disclosure>
      </div>
    </aside>
  )
}

function Studio() {
  return (
    <main className="workspace workspace--studio">
      <div className="studio-main">
        <div className="workspace-title">
          <div>
            <span className="eyebrow">Active scene · espresso-machine.bip</span>
            <h1>Studio</h1>
          </div>
          <span className="scene-state">
            <span className="status-dot status-dot--live" /> Synced just now
          </span>
        </div>
        <SceneCanvas />
        <DirectorChat />
      </div>
      <StudioInspector />
    </main>
  )
}

const references = [
  { name: "Warm editorial", tone: "amber" },
  { name: "Midnight chrome", tone: "blue" },
  { name: "Soft daylight", tone: "white" },
  { name: "Clay studio", tone: "clay" },
  { name: "Hard flash", tone: "red" },
  { name: "Gallery calm", tone: "sage" },
]

function References() {
  const [selected, setSelected] = useState(0)
  const [query, setQuery] = useState("")
  const visible = references.filter((item) =>
    item.name.toLowerCase().includes(query.toLowerCase()),
  )
  return (
    <main className="workspace workspace--library">
      <section className="library-main">
        <div className="workspace-title workspace-title--actions">
          <div>
            <span className="eyebrow">Visual library</span>
            <h1>References</h1>
            <p>Organize the looks that shape your scenes.</p>
          </div>
          <Button icon={Upload} variant="primary">
            Add references
          </Button>
        </div>
        <div className="library-toolbar">
          <label className="search-field">
            <Search />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search references"
            />
          </label>
          <Button icon={SlidersHorizontal} compact>
            Filter
          </Button>
          <Button icon={Folder} compact>
            New folder
          </Button>
        </div>
        <div className="folder-tabs">
          {["All references", "Commerce", "Closeups", "Materials"].map(
            (item, index) => (
              <button className={index === 0 ? "is-active" : ""} key={item}>
                {item}
              </button>
            ),
          )}
        </div>
        <div className="reference-grid">
          {visible.map((item) => {
            const originalIndex = references.indexOf(item)
            return (
              <button
                className={`reference-card ${
                  selected === originalIndex ? "is-selected" : ""
                }`}
                key={item.name}
                onClick={() => setSelected(originalIndex)}
              >
                <span
                  className={`reference-visual reference-visual--${item.tone}`}
                >
                  <span />
                </span>
                <span className="reference-card__label">
                  <span>
                    <strong>{item.name}</strong>
                    <small>Commerce · JPG</small>
                  </span>
                  {selected === originalIndex && <Check />}
                </span>
              </button>
            )
          })}
        </div>
      </section>
      <aside className="detail-panel">
        <div className="detail-panel__top">
          <span>Reference details</span>
          <IconButton icon={MoreHorizontal} label="Reference options" />
        </div>
        <div
          className={`selected-preview reference-visual--${references[selected].tone}`}
        >
          <span />
        </div>
        <div className="detail-copy">
          <h2>{references[selected].name}</h2>
          <p>Selected visual reference</p>
        </div>
        <label className="field">
          <span>Matching brief</span>
          <textarea
            rows={4}
            defaultValue="Borrow the broad side light, controlled highlights, and quiet background separation."
          />
        </label>
        <Button icon={WandSparkles} variant="primary" className="full-width">
          Use in Match a look
        </Button>
        <div className="evidence">
          <span className="field-label">Recent match evidence</span>
          <div className="evidence__pair">
            <span>Before</span>
            <span>After</span>
          </div>
          <p>
            <Check /> Last applied 18 minutes ago
          </p>
        </div>
        <Button icon={Download} variant="ghost" className="full-width">
          Export reference
        </Button>
      </aside>
    </main>
  )
}

function Materials() {
  const [editMode, setEditMode] = useState(false)
  const [material, setMaterial] = useState("Brushed steel")
  return (
    <main className="workspace workspace--materials">
      <aside className="material-list">
        <div className="workspace-title">
          <div>
            <span className="eyebrow">Scene materials</span>
            <h1>Materials</h1>
          </div>
        </div>
        <label className="search-field">
          <Search />
          <input placeholder="Search materials" />
        </label>
        <div className="material-items">
          {[
            ["Brushed steel", "metal"],
            ["Black glass", "glass"],
            ["Warm aluminum", "aluminum"],
            ["Control labels", "label"],
          ].map(([name, tone]) => (
            <button
              className={material === name ? "is-active" : ""}
              key={name}
              onClick={() => setMaterial(name)}
            >
              <span className={`swatch swatch--${tone}`} />
              <span>
                <strong>{name}</strong>
                <small>Applied to 1 part</small>
              </span>
            </button>
          ))}
        </div>
      </aside>
      <section className="material-editor">
        <div className="material-editor__header">
          <div>
            <span className="eyebrow">
              {editMode ? "Editing material" : "Read-only safeguard"}
            </span>
            <h2>{material}</h2>
            <p>
              {editMode
                ? "Changes are staged until you save them."
                : "Inspect properties without changing the KeyShot material."}
            </p>
          </div>
          <div className="header-actions">
            {editMode ? (
              <>
                <Button onClick={() => setEditMode(false)}>Discard</Button>
                <Button
                  icon={Save}
                  variant="primary"
                  onClick={() => setEditMode(false)}
                >
                  Save changes
                </Button>
              </>
            ) : (
              <Button
                icon={SlidersHorizontal}
                variant="primary"
                onClick={() => setEditMode(true)}
              >
                Edit material
              </Button>
            )}
          </div>
        </div>
        <div className="material-preview">
          <div className="material-orb">
            <span />
          </div>
          <span>Material preview</span>
        </div>
        <div className={`property-grid ${editMode ? "" : "is-locked"}`}>
          <label className="range-field">
            <span>
              <span>Roughness</span>
              <output>0.32</output>
            </span>
            <input disabled={!editMode} type="range" defaultValue="32" />
          </label>
          <label className="range-field">
            <span>
              <span>Metallic</span>
              <output>0.91</output>
            </span>
            <input disabled={!editMode} type="range" defaultValue="91" />
          </label>
          <label className="range-field">
            <span>
              <span>Coat</span>
              <output>0.18</output>
            </span>
            <input disabled={!editMode} type="range" defaultValue="18" />
          </label>
          <label className="range-field">
            <span>
              <span>Anisotropy</span>
              <output>0.64</output>
            </span>
            <input disabled={!editMode} type="range" defaultValue="64" />
          </label>
        </div>
        <section className="asset-section">
          <div className="section-heading section-heading--compact">
            <div>
              <h2>Texture & reference assets</h2>
              <p>Files stay linked to this material.</p>
            </div>
            <Button icon={Plus} compact disabled={!editMode}>
              Add asset
            </Button>
          </div>
          <div className="asset-row">
            <span className="asset-thumb">
              <Layers3 />
            </span>
            <span>
              <strong>steel_brushed_2k.jpg</strong>
              <small>Roughness map · 2048 × 2048</small>
            </span>
            <span className="state-badge state-badge--success">
              <Check /> Linked
            </span>
          </div>
        </section>
      </section>
      <aside className="material-assistant">
        <div className="detail-panel__top">
          <span>Material assistant</span>
          <Sparkles />
        </div>
        <div className="assistant-empty">
          <span className="empty-icon">
            <Sparkles />
          </span>
          <strong>Refine with direction</strong>
          <p>
            Ask for a material adjustment. Changes remain staged until you
            review and save.
          </p>
        </div>
        <div className="mini-suggestions">
          {["Softer brushing", "Reduce reflections", "Warmer metal"].map(
            (item) => (
              <button key={item}>{item}</button>
            ),
          )}
        </div>
        <div className="mini-composer">
          <textarea rows={3} placeholder="Describe a material change…" />
          <Button
            icon={ArrowUp}
            variant="primary"
            compact
            aria-label="Send material request"
          />
        </div>
      </aside>
    </main>
  )
}

function AppHeader({
  workspace,
  setWorkspace,
}: {
  workspace: Workspace
  setWorkspace: (workspace: Workspace) => void
}) {
  const [mobileOpen, setMobileOpen] = useState(false)
  return (
    <header className="app-header">
      <div className="brand">
        <span className="brand-mark">
          <Aperture />
        </span>
        <span>
          <strong>KeyShot</strong>
          <small>Director</small>
        </span>
      </div>
      <nav
        className={`workspace-nav ${mobileOpen ? "is-open" : ""}`}
        aria-label="Workspace"
      >
        {[
          ["studio", Monitor, "Studio"],
          ["references", Image, "References"],
          ["materials", Layers3, "Materials"],
        ].map(([id, Icon, label]) => (
          <button
            className={workspace === id ? "is-active" : ""}
            key={id as string}
            onClick={() => {
              setWorkspace(id as Workspace)
              setMobileOpen(false)
            }}
          >
            <Icon aria-hidden="true" />
            {label as string}
          </button>
        ))}
      </nav>
      <div className="header-meta">
        <span className="connection">
          <span className="status-dot status-dot--live" />
          <span>KeyShot connected</span>
        </span>
        <span className="provider">OpenAI · Codex</span>
        <IconButton label="Help" icon={CircleHelp} />
        <IconButton label="Settings" icon={Settings} />
        <IconButton
          label="Open navigation"
          icon={mobileOpen ? X : Menu}
          onClick={() => setMobileOpen(!mobileOpen)}
        />
      </div>
    </header>
  )
}

export default function App() {
  const [workspace, setWorkspace] = useState<Workspace>("studio")
  return (
    <div className="app-shell">
      <AppHeader workspace={workspace} setWorkspace={setWorkspace} />
      {workspace === "studio" && <Studio />}
      {workspace === "references" && <References />}
      {workspace === "materials" && <Materials />}
    </div>
  )
}
